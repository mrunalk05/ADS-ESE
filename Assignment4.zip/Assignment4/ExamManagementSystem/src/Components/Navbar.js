import React, { useEffect, useState } from "react";
import Cookies from 'js-cookie';

function Navbar() {
    const [data, setData] = useState('');
    const [type, settype] = useState('');
    useEffect(async () => {
        var data = Cookies.get('user');
        var type = Cookies.get('type');
        setData(data);
        settype(type);
    }, []);
const logout = async () => {
    Cookies.remove('user');
    Cookies.remove('type');
    window.location.href = '/';
}
    return (
        <>
            <header id="header" class="fixed-top" style={{ backgroundColor: 'black' }}>
                <div class="container d-flex align-items-center justify-content-between">
                    <h1 class="logo"><a href="/">ADS Assignment 4</a></h1>

                    <nav id="navbar" class="navbar">
                        {(data != undefined && type != undefined) ? 
                            (type === 'student'?
                            <ul>
                                <li class="dropdown"><a class="getstarted scrollto" href="#"><span>{data}</span> <i class="bi bi-chevron-down"></i> </a>

                                    <ul>
                                        {/* <li><a href="/shelf">My Shelf</a></li>
                                        <li><a href="/cpass">Change Password</a></li> */}
                                        <li><a href="/"  onClick={logout}>Log Out</a></li>
                                    </ul>
                                </li>
                            </ul>
                            :<ul>
                            <li class="dropdown"><a class="getstarted scrollto" href="#"><span>{data}</span> <i class="bi bi-chevron-down"></i> </a>

                                <ul>
                                    {/* <li><a href="/shelf">My Shelf</a></li>
                                    <li><a href="/cpass">Change Password</a></li> */}
                                   <li><a href="/"  onClick={logout}>Log Out</a></li>
                                </ul>
                            </li>
                        </ul>)
                            : <ul>
                            </ul>}

                        <i class="bi bi-list mobile-nav-toggle"></i>
                    </nav>

                </div>
            </header>

        </>
    );
}

export default Navbar;