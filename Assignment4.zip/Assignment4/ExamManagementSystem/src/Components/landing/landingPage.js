import React from "react";
import  { useEffect, useState } from "react";
import Cookies from 'js-cookie';
import "./landing.css";
function Landing() {
    const [data, setData] = useState('');
    const [type, settype] = useState('');
    useEffect(async () => {
        var data = Cookies.get('user');
        var type = Cookies.get('type');
        setData(data);
        settype(type);
    }, []);
const logout = async () => {
    Cookies.remove('user');
    Cookies.remove('type');
    window.location.href = '/';
}
    return (
        <div>
            <div className="home">
                <div>
                    <div className='container container-fluid text-center text-primary'>
                        <h3 style={{ marginBottom: '10px', paddingTop: '15px' }}>QuizApp </h3>
                    </div>
                </div>
                {/* <section id="about" class="about">
                    <div class="container">

                        <div class="row">
                            <div class="col-lg-6 order-1 order-lg-2" data-aos="zoom-in" data-aos-delay="150">
                                <img src="/bg.png " class="img-fluid" alt="" />
                            </div>
                            <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content text-dark" data-aos="fade-right">
                                <h3>About Us - </h3>
                                <p class="font-italic">
                                <ul className="checkmark-list">
                                <li>
                                    Admin has all the access to see all the data and Edit it.
                                </li>
                                <li>
                                   To access or manage the data go to navbar's manage ,
                                   then a dropdown will pop up choose the section you want see or modify. 
                                </li>
                              
                                <li>
                                    you will see the data of that selected section.
                                </li>
                                <li>
                                    If you want to add the data directly hover on section you want to edit in manage and infront of that you will see add and view buttons click on that.
                                </li>
                                <li>You can also directly add the data of any section from the view data page of the same section as at bottom-right their is a add icon which will redirct you to add page of that section. </li>
                            </ul>
                                </p>
                            </div>
                        </div>

                    </div>
                </section> */}
                <div class="container d-flex align-items-center justify-content-between">
                 {/*   <h1 class="logo"><a href="/">ADS Assignment 4</a></h1>*/}

                        {(data != undefined && type != undefined) ? 
                            (type === 'student'?
                           
                            <div class="studentquiz" >
                            <a class=" scrollto" href="/AllQuizPage">Select Quiz</a>
                            </div>
                             
                            :
                            <div  class="facultyLanding">

                            <a  href="/AddNewQuiz">Add New Quiz</a>
                            <br></br>
                            <a  href="/TeacherViewNew">Add New Question</a>
                            <br></br>
                            <a  href="/TeacherViewUpdate">Update Question</a>
                            <br></br>
                           </div>
                        )
                            : <div  class="landing">
                                <a class="nav-link scrollto" href="/studentLogin">student login</a>
                                <a class="nav-link scrollto" href="/facultyLogin">Faculty login</a>
                                <a class="nav-link scrollto" href="/register">Register</a>
                            </div>}

                        <i class="bi bi-list mobile-nav-toggle"></i>
                    
                </div>
            </div>
        </div>
    );
}

export default Landing;